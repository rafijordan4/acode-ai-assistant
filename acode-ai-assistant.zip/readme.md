# AI Assistant — Acode Plugin
by Rafi Studio

## Install
1. Acode → Settings → Plugins → ikon (+)
2. Pilih file ZIP ini
3. Restart Acode

## Cara Pakai
1. Klik ikon 🤖 pojok kanan bawah
2. Tab Settings → isi API Key dari openrouter.ai → Simpan
3. Tab Generate → pilih mode, tulis prompt, klik Generate

## Mode
- 📁 Folder — buat struktur folder + file otomatis
- 📄 Script — buat kode/script
- 🖼️ Gambar — buat gambar SVG
- 💬 Bebas — tanya apa saja

## Dapat API Key Gratis
https://openrouter.ai/keys
